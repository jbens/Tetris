import javax.swing.JComponent;


@SuppressWarnings("serial")
public class Preview extends JComponent {
	
}
