
public enum Direction {
	NONE, UP, DOWN, LEFT, RIGHT, CCW, CW
}
