
public enum Shape {
	O, I, J, L, Z, S, T
}
